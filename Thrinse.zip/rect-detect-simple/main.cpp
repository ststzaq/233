#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <algorithm>
#include <cctype>
#include <cmath>
#include <filesystem>
#include <iostream>
#include <string>
#include <vector>

using namespace std;
using namespace cv;
namespace fs = std::filesystem;

// 四个角、凸多边形，而且每个角都接近 90 度。
bool isRectangle(const vector<Point>& p) {
    if (p.size() != 4 || !isContourConvex(p)) return false;
    for (int i = 0; i < 4; i++) {
        Point2f a = p[(i + 1) % 4] - p[i];
        Point2f b = p[(i + 3) % 4] - p[i];
        double length = norm(a) * norm(b);
        // 两条边垂直时，点积为 0。这里允许一点像素误差。
        if (length == 0 || abs(a.dot(b)) > 0.2 * length) return false;
    }
    return true;
}

// 从图像中最上方的角开始，同高取左边，然后沿画面顺时针排列。
void orderPoints(vector<Point>& p) {
    if (contourArea(p, true) < 0) reverse(p.begin(), p.end());
    int first = 0;
    for (int i = 1; i < 4; i++) {
        if (p[i].y < p[first].y ||
            (p[i].y == p[first].y && p[i].x < p[first].x)) first = i;
    }
    rotate(p.begin(), p.begin() + first, p.end());
}

// 同一条边可能找出内外两圈轮廓，角点相近时只保留一次。
bool sameRectangle(const vector<Point>& a, const vector<Point>& b) {
    for (int start = 0; start < 4; start++) {
        bool same = true;
        for (int i = 0; i < 4; i++) {
            if (norm(a[i] - b[(i + start) % 4]) > 6) same = false;
        }
        if (same) return true;
    }
    return false;
}

int main(int argc, char* argv[]) {
    fs::path input = argc > 1 ? argv[1] : "/input";
    fs::path output = argc > 2 ? argv[2] : "/out";
    try {
        if (!fs::is_directory(input)) {
            cerr << "Input directory does not exist: " << input << '\n';
            return 1;
        }
        fs::create_directories(output);

        vector<fs::path> files;
        for (const auto& entry : fs::directory_iterator(input)) {
            if (!entry.is_regular_file()) continue;
            string ext = entry.path().extension().string();
            for (char& c : ext) c = static_cast<char>(tolower(static_cast<unsigned char>(c)));
            if (ext == ".png") files.push_back(entry.path());
        }
        sort(files.begin(), files.end());

        bool failed = false;
        for (const auto& file : files) {
            Mat image = imread(file.string(), IMREAD_COLOR);
            if (image.empty()) {
                cerr << "Cannot read: " << file << '\n';
                failed = true;
                continue;
            }

            // 三个颜色通道分别找边缘，再合并，避免转灰度后丢掉色差。
            vector<Mat> channels;
            split(image, channels);
            Mat edges = Mat::zeros(image.size(), CV_8UC1);
            for (Mat channel : channels) {
                Mat edge;
                GaussianBlur(channel, channel, Size(3, 3), 0);
                Canny(channel, edge, 10, 30);
                bitwise_or(edges, edge, edges);
            }

            vector<vector<Point>> contours, rectangles;
            // RETR_LIST 也会查找大框里面的小框。
            findContours(edges, contours, RETR_LIST, CHAIN_APPROX_SIMPLE);
            for (const auto& contour : contours) {
                vector<Point> p;
                approxPolyDP(contour, p, arcLength(contour, true) * 0.02, true);
                if (!isRectangle(p)) continue;
                orderPoints(p);
                bool repeated = false;
                for (auto& r : rectangles) {
                    if (sameRectangle(p, r)) {
                        // 内外两圈都找到时，留下外圈，避免角点偏到框内。
                        if (abs(contourArea(p)) > abs(contourArea(r))) r = p;
                        repeated = true;
                        break;
                    }
                }
                if (!repeated) rectangles.push_back(p);
            }

            // 让 rect1、rect2 的顺序也固定下来：先上后下，同高先左后右。
            sort(rectangles.begin(), rectangles.end(),
                 [](const vector<Point>& a, const vector<Point>& b) {
                     if (a[0].y != b[0].y) return a[0].y < b[0].y;
                     return a[0].x < b[0].x;
                 });

            for (const auto& r : rectangles) polylines(image, r, true, Scalar(0, 255, 0), 2);
            if (!imwrite((output / file.filename()).string(), image)) {
                cerr << "Cannot save: " << output / file.filename() << '\n';
                failed = true;
            }

            cout << file.filename().string() << ": ";
            if (rectangles.empty()) cout << "null";
            for (size_t i = 0; i < rectangles.size(); i++) {
                if (i > 0) cout << " | ";
                cout << "rect" << i + 1 << ' ';
                for (int j = 0; j < 4; j++) {
                    if (j > 0) cout << "; ";
                    Point p = rectangles[i][j];
                    // OpenCV 的原点在左上，考核要求的原点在左下。
                    cout << '(' << p.x << ", " << image.rows - 1 - p.y << ')';
                }
            }
            cout << '\n';
        }
        return failed ? 1 : 0;
    } catch (const exception& e) {
        cerr << e.what() << '\n';
        return 1;
    }
}
